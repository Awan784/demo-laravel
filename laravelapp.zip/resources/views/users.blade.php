@extends("template.interface")
@section("content")
    <h3>All Users</h3>
    @if(Session::has("error"))

            <div class="alert alert-danger">{{session('error')}}</div>

    @endif
    @if(Session::has("success"))

    <div class="alert alert-success">{{session('success')}}</div>

@endif
<form class="form-inline" method="post" action="{{url('users')}}">
    @csrf
    <label for="email">Username</label>
    <input type="text" name="username" class="form-control" placeholder="Enter Username" id="email" required>
    <label for="pwd">Password:</label>
    <input type="password" name="password" class="form-control" placeholder="Enter password" id="pwd" required>
    <label for="firstname">First Name:</label>
    <input type="text" name="firstname" class="form-control" placeholder="Enter First Name" id="firstname" required>
    <label for="lastname">Last Name:</label>
    <input type="text" name="lastname" class="form-control" placeholder="Enter Last Name" id="lastname" required>
    <button type="submit" class="btn btn-primary">Regiser New User</button>
  </form>
  <br/>
    <table class="table table-bordered table-hover table-striped table-sm">
        <thead>
            <tr>
                <th>Id</th>
                <th>Username</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody>
            @foreach($users as $user)

                <tr>
                    <td>{{$user->id}}</td>
                    <td>{{$user->username}}</td>
                    <td>{{$user->firstname}}</td>
                    <td>{{$user->lastname}}</td>
                    <td>
                        <a href="{{url('users/delete')}}/{{$user->id}}" class="btn btn-danger btn-sm" onclick="return confirm('are you sure you want to delete?')">Delete</a>
                    </td>
                </tr>

            @endforeach

        </tbody>

    </table>


@endsection