@extends("template.interface")
@section("content")
    <h3>Use the top menu to use dashboard features</h3>
@endsection