
<?php $__env->startSection("content"); ?>
    <h3>Use the top menu to use dashboard features</h3>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("template.interface", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\exampleapp\resources\views/dashboard.blade.php ENDPATH**/ ?>