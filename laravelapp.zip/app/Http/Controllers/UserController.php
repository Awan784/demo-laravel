<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\UserModel as User;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    public function Index(Request $request){
        
        if($request->session()->has("onlineuser")){
            return view("dashboard");
        }
        return view("welcome");
    }

    public function ProcessLogin(Request $request){

        $user = User::where("username",$request->username)->first();

        if($user != null){

            if(Hash::check($request->password,$user->password)){

                    $request->session()->put("onlineuser",$user);
                    return redirect("/");


            }

        }

        return redirect("/")->with("error","Wrong username or password");

    }

    public function Logout(Request $request){
        $request->session()->pull("onlineuser");
        return redirect("/");
    }

    public function All(Request $request){

        $users = User::all();
        return view("users",compact('users'));

    }

    public function SaveUser(Request $request){

        $isExists = User::where("username",$request->username)->count();
        if($isExists <= 0){

            $user = new User();
            $data = $request->all();
            $data["password"] = Hash::make($data["password"]);
            $user->fill($data);
            $user->save();
            return redirect("/users")->with("success","User saved successfully");

        }

        return redirect("/users")->with("error","The user with this username already exists");


    }

    public function DeleteUser(Request $request,$id){

        $onlineuserid = $request->session()->get("onlineuser")->id;

        if($onlineuserid != $id){

            $user = User::find($id);
            $user->delete();
            return redirect("users")->with("success","User deleted successfully");


        }


        return redirect("users")->with("error","You can not delete this user as  it is already logged in");

    }


}
