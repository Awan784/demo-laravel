
<?php $__env->startSection("content"); ?>
    <h3>All Users</h3>
    <?php if(Session::has("error")): ?>

            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>

    <?php endif; ?>
    <?php if(Session::has("success")): ?>

    <div class="alert alert-success"><?php echo e(session('success')); ?></div>

<?php endif; ?>
<form class="form-inline" method="post" action="<?php echo e(url('users')); ?>">
    <?php echo csrf_field(); ?>
    <label for="email">Username</label>
    <input type="text" name="username" class="form-control" placeholder="Enter Username" id="email" required>
    <label for="pwd">Password:</label>
    <input type="password" name="password" class="form-control" placeholder="Enter password" id="pwd" required>
    <label for="firstname">First Name:</label>
    <input type="text" name="firstname" class="form-control" placeholder="Enter First Name" id="firstname" required>
    <label for="lastname">Last Name:</label>
    <input type="text" name="lastname" class="form-control" placeholder="Enter Last Name" id="lastname" required>
    <button type="submit" class="btn btn-primary">Regiser New User</button>
  </form>
  <br/>
    <table class="table table-bordered table-hover table-striped table-sm">
        <thead>
            <tr>
                <th>Id</th>
                <th>Username</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td><?php echo e($user->id); ?></td>
                    <td><?php echo e($user->username); ?></td>
                    <td><?php echo e($user->firstname); ?></td>
                    <td><?php echo e($user->lastname); ?></td>
                    <td>
                        <a href="<?php echo e(url('users/delete')); ?>/<?php echo e($user->id); ?>" class="btn btn-danger btn-sm" onclick="return confirm('are you sure you want to delete?')">Delete</a>
                    </td>
                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>

    </table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make("template.interface", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\exampleapp\resources\views/users.blade.php ENDPATH**/ ?>